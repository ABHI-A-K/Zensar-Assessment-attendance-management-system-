from django.apps import AppConfig


class StuMngSysConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'stu_mng_sys'
