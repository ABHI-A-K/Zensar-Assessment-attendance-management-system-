from django.shortcuts import render,redirect
from .models import Att_mng,StudentData
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login

# Create your views here.

def cont(request):
      return render(request,"linking1.html",context={})

def addstudent(request):
    if request.method == 'POST':
        name = request.POST.get("name")
        address = request.POST.get("address")
        Rollno = request.POST.get("Rollno")
        Bloodgroup = request.POST.get("Bloodgroup")
        b = StudentData(name,address,Rollno,Bloodgroup)
        b.save()
    else:
        return render(request,"manage_emp.html",context={})   
    return redirect("Abhi4") 

def attendance(request):
    if request.method == 'POST':
        Roll_n = request.POST.get("Rollnum")
        n = request.POST.get("name")
        date = request.POST.get("Date")
        d = request.POST.get("day")
        sta = request.POST.get("status")
        dp = request.POST.get("days_p")
        a_p = request.POST.get("att_p")
        c = Att_mng(Rollnum = Roll_n, name = n,day = d,status = sta,days_p = dp,Date = date,att_p=a_p)
        c.save()
    else:
        return render(request,"tsheet.html",context={})    
    return redirect("Abhi4") 

def Teacherlogin(request):
    try:    
        if request.method == 'POST':
            usern = request.POST.get("username")
            passw = request.POST.get("password")
            a = User.objects.create_user(username = usern,password = passw,is_staff = True, is_active = True, is_superuser = True)
            a = a.save()
            userObj=User.objects.get(username=usern)
            if userObj is not None:
                user1=authenticate(request,username=usern,password=passw)
                print("user Found")
                if user1 == usern:
                    return redirect("Abhi6")
        else:
            return render(request,"loginform.html",context={})
        return redirect("Abhi4")
    except:
        return redirect("Abhi4")

def sturep(request):
    s_rep = StudentData.objects.all()
    #print(e_rep)
    return render(request,"emprep.html",context={"s_rep":s_rep})

def att_rep(request):
    att_rep = Att_mng.objects.all()
    #print(e_rep)
    return render(request,"trep.html",context={"att_rep":att_rep})



