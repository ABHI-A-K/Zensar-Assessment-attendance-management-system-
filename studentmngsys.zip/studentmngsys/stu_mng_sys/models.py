from django.db import models
from email.policy import default
from unittest.util import _MAX_LENGTH

# Create your models here.
class Att_mng(models.Model):
    Rollnum = models.IntegerField(primary_key = True)
    name =  models.CharField(max_length=40)
    Date = models.DateField()
    day = models.CharField(max_length=40)
    status = models.CharField(max_length=40)
    days_p = models.IntegerField()
    att_p = models.CharField(max_length=10,default = 0)


class StudentData(models.Model):
    name = models.CharField(max_length=40)
    address = models.CharField(max_length=120,default="Vagdevi")
    Rollno = models.IntegerField(primary_key = True)
    Bloodgroup = models.CharField(max_length=40)
