from stu_mng_sys import views
from django.urls import URLPattern, path

urlpatterns = [
    path('stu_mng/',views.addstudent,name="Abhi1"),
    path('attsheet/',views.attendance,name="Abhi2"),
    path('sturep/',views.sturep,name="Abhi3"),
    path('welcome/',views.cont,name="Abhi4"),
    path('attrep/',views.att_rep,name="Abhi5"),
    path('Teacherlog/',views.Teacherlogin,name="Abhi6")
]